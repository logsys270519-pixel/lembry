import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Trash2, Plus } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface StickerData {
  id: number;
  content: string;
  positionX: number;
  positionY: number;
  zIndex: number;
  color: string;
}

interface DraggingSticker {
  id: number;
  startX: number;
  startY: number;
  currentX: number;
  currentY: number;
}

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [stickers, setStickers] = useState<StickerData[]>([]);
  const [draggingSticker, setDraggingSticker] = useState<DraggingSticker | null>(null);
  const [editingStickerId, setEditingStickerId] = useState<number | null>(null);
  const [editingContent, setEditingContent] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newStickerContent, setNewStickerContent] = useState("");
  const [newStickerColor, setNewStickerColor] = useState("yellow");
  const containerRef = useRef<HTMLDivElement>(null);
  const maxZIndex = useRef(1);

  const { data: fetchedStickers, isLoading: isLoadingStickers } = trpc.stickers.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const createMutation = trpc.stickers.create.useMutation();
  const updateMutation = trpc.stickers.update.useMutation();
  const deleteMutation = trpc.stickers.delete.useMutation();

  useEffect(() => {
    if (fetchedStickers) {
      setStickers(fetchedStickers);
      const maxZ = Math.max(...fetchedStickers.map(s => s.zIndex), 1);
      maxZIndex.current = maxZ;
    }
  }, [fetchedStickers]);

  const handleCreateSticker = async () => {
    if (!newStickerContent.trim()) return;

    try {
      await createMutation.mutateAsync({
        content: newStickerContent,
        positionX: 50,
        positionY: 50,
        color: newStickerColor,
      });
      setNewStickerContent("");
      setNewStickerColor("yellow");
      setIsCreateDialogOpen(false);
      if (fetchedStickers) {
        setStickers([
          ...stickers,
          {
            id: Date.now(),
            content: newStickerContent,
            positionX: 50,
            positionY: 50,
            zIndex: maxZIndex.current + 1,
            color: newStickerColor,
          },
        ]);
      }
    } catch (error) {
      console.error("Failed to create sticker:", error);
    }
  };

  const handleMouseDown = (e: React.MouseEvent, stickerId: number) => {
    if ((e.target as HTMLElement).closest("button")) return;

    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const containerRect = containerRef.current?.getBoundingClientRect();

    if (!containerRect) return;

    setDraggingSticker({
      id: stickerId,
      startX: e.clientX - rect.left,
      startY: e.clientY - rect.top,
      currentX: rect.left - containerRect.left,
      currentY: rect.top - containerRect.top,
    });

    maxZIndex.current += 1;
    setStickers(stickers.map(s => 
      s.id === stickerId ? { ...s, zIndex: maxZIndex.current } : s
    ));
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggingSticker || !containerRef.current) return;

    const containerRect = containerRef.current.getBoundingClientRect();
    const newX = e.clientX - containerRect.left - draggingSticker.startX;
    const newY = e.clientY - containerRect.top - draggingSticker.startY;

    setStickers(stickers.map(s =>
      s.id === draggingSticker.id
        ? { ...s, positionX: Math.max(0, newX), positionY: Math.max(0, newY) }
        : s
    ));
  };

  const handleMouseUp = async () => {
    if (!draggingSticker) return;

    const sticker = stickers.find(s => s.id === draggingSticker.id);
    if (sticker) {
      try {
        await updateMutation.mutateAsync({
          id: sticker.id,
          positionX: sticker.positionX,
          positionY: sticker.positionY,
          zIndex: sticker.zIndex,
        });
      } catch (error) {
        console.error("Failed to update sticker position:", error);
      }
    }

    setDraggingSticker(null);
  };

  const handleEditSticker = (sticker: StickerData) => {
    setEditingStickerId(sticker.id);
    setEditingContent(sticker.content);
  };

  const handleSaveEdit = async () => {
    if (!editingStickerId || !editingContent.trim()) return;

    try {
      await updateMutation.mutateAsync({
        id: editingStickerId,
        content: editingContent,
      });
      setStickers(stickers.map(s =>
        s.id === editingStickerId ? { ...s, content: editingContent } : s
      ));
      setEditingStickerId(null);
      setEditingContent("");
    } catch (error) {
      console.error("Failed to save sticker:", error);
    }
  };

  const handleDeleteSticker = async (stickerId: number) => {
    try {
      await deleteMutation.mutateAsync({ id: stickerId });
      setStickers(stickers.filter(s => s.id !== stickerId));
    } catch (error) {
      console.error("Failed to delete sticker:", error);
    }
  };

  const getPostItClass = (color: string) => {
    switch (color) {
      case "pink":
        return "postit postit-pink";
      case "blue":
        return "postit postit-blue";
      case "green":
        return "postit postit-green";
      default:
        return "postit postit-yellow";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-foreground">Carregando...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center">
        <div className="text-center space-y-8">
          <img src={APP_LOGO} alt="Lembry" className="w-32 h-32 mx-auto" />
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">{APP_TITLE}</h1>
            <p className="text-lg text-muted-foreground mb-8">
              Seus lembretes sempre à mão, em qualquer lugar da tela
            </p>
          </div>
          <div className="space-y-4">
            <Button
              size="lg"
              onClick={() => window.location.href = getLoginUrl()}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              Entrar com Manus
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={APP_LOGO} alt="Lembry" className="w-10 h-10" />
            <h1 className="text-2xl font-bold text-foreground">{APP_TITLE}</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Bem-vindo, {user?.name}</span>
            <Button
              variant="outline"
              size="sm"
              onClick={logout}
              className="text-foreground"
            >
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Trash and Create Buttons */}
      <div className="fixed top-20 right-6 z-50 flex gap-3 items-center">
        <button
          onClick={() => setIsCreateDialogOpen(true)}
          className="bg-accent hover:bg-accent/90 text-accent-foreground rounded-full p-4 shadow-lg hover:shadow-xl transition-all hover:scale-110"
        >
          <Plus className="w-6 h-6" />
        </button>
        <div className="bg-destructive text-destructive-foreground rounded-full p-4 shadow-lg hover:shadow-xl transition-shadow cursor-pointer hover:scale-110">
          <Trash2 className="w-6 h-6" />
        </div>
      </div>

      {/* Main Canvas */}
      <div
        ref={containerRef}
        className="relative w-full h-[calc(100vh-80px)] overflow-hidden"
        style={{
          backgroundImage: 'url(/background-texture.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Stickers */}
        {isLoadingStickers ? (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            Carregando seus lembretes...
          </div>
        ) : (
          stickers.map(sticker => (
            <div
              key={sticker.id}
              className={`absolute w-64 p-4 cursor-move transition-all ${getPostItClass(sticker.color)} ${
                draggingSticker?.id === sticker.id ? "dragging" : ""
              }`}
              style={{
                left: `${sticker.positionX}px`,
                top: `${sticker.positionY}px`,
                zIndex: sticker.zIndex,
              }}
              onMouseDown={(e) => handleMouseDown(e, sticker.id)}
            >
              {/* Post-it fold corner */}
              <div className="postit-fold"></div>

              {editingStickerId === sticker.id ? (
                <div className="space-y-2">
                  <Textarea
                    value={editingContent}
                    onChange={(e) => setEditingContent(e.target.value)}
                    className="w-full h-32 resize-none text-sm bg-white/50 border-0 focus:outline-none focus:ring-2 focus:ring-primary"
                    autoFocus
                  />
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={handleSaveEdit}
                      className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                    >
                      OK
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditingStickerId(null)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-gray-800 whitespace-pre-wrap break-words leading-relaxed font-sans">
                    {sticker.content || <span className="text-gray-400 italic">Escreva aqui...</span>}
                  </p>
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      onClick={() => handleEditSticker(sticker)}
                      className="flex-1 bg-blue-500 hover:bg-blue-600 text-white text-xs"
                    >
                      Editar
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteSticker(sticker.id)}
                      className="flex-1 text-xs"
                    >
                      Deletar
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Create Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Novo Lembrete</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="Digite seu lembrete aqui..."
              value={newStickerContent}
              onChange={(e) => setNewStickerContent(e.target.value)}
              className="w-full h-32 resize-none"
              autoFocus
            />
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Cor</label>
              <div className="flex gap-2">
                {[
                  { name: "yellow", label: "Amarelo", bg: "#fef3c7" },
                  { name: "pink", label: "Rosa", bg: "#fce7f3" },
                  { name: "blue", label: "Azul", bg: "#dbeafe" },
                  { name: "green", label: "Verde", bg: "#dcfce7" },
                ].map(color => (
                  <button
                    key={color.name}
                    onClick={() => setNewStickerColor(color.name)}
                    className={`flex-1 h-10 rounded-lg border-2 transition-all font-medium text-xs ${
                      newStickerColor === color.name ? "border-foreground scale-110" : "border-transparent"
                    }`}
                    style={{ backgroundColor: color.bg }}
                    title={color.label}
                  >
                    {color.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleCreateSticker}
                disabled={!newStickerContent.trim()}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                Criar
              </Button>
              <Button
                variant="outline"
                onClick={() => setIsCreateDialogOpen(false)}
                className="flex-1"
              >
                Cancelar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
